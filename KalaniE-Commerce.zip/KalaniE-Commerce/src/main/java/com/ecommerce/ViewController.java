package com.ecommerce;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
/**
 * @author Rahul Kalani
 */
@Controller
public class ViewController {
    
    public ViewController()
    {
        
    }

    //Mapping URL requests - Login
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String Login(ModelMap MM)
    {
        MM.addAttribute("login");
        return "Login";
    }
    
    //Mapping URL requests - Login after signup
    @RequestMapping(value = "/LoginAfterSignup", method = RequestMethod.GET)
    public String LoginAfterSignup(ModelMap MM)
    {
        MM.addAttribute("login");
        return "Login";
    }
    
    //Mapping URL requests - MainMenu
    @RequestMapping(value = "/MainMenu", method = RequestMethod.POST)
    public String MainMenu(ModelMap MM)
    {
        MM.addAttribute("mainmenu");
        return "MainMenu";
    }

    //Mapping URL requests - Regseter
    @RequestMapping(value = "/Register", method = RequestMethod.GET)
    public String Register(ModelMap MM) 
    {
        MM.addAttribute("register");
        return "Register";
    }
    
    //Mapping URL requests - Forgot Password
    @RequestMapping(value = "/ForgotPassword", method = RequestMethod.GET)
    public String ForgotPassword(ModelMap MM)
    {
        MM.addAttribute("forgotpassword");
        return "ForgotPassword";
    }
    
    //Mapping URL requests - View Profile
    @RequestMapping(value = "/ViewProfile", method = RequestMethod.GET)
    public String ViewProfile(ModelMap MM)
    {
        MM.addAttribute("viewprofile");
        return "ViewProfile";
    }
    
    //Mapping URL requests - View Items
    @RequestMapping(value = "/ViewItems", method = RequestMethod.GET)
    public String ViewItems(ModelMap MM)
    {
        MM.addAttribute("viewitems");
        return "ViewItems";
    }
    
    //Mapping URL requests - Sell Item
    @RequestMapping(value = "/SellItem", method = RequestMethod.GET)
    public String SellItems(ModelMap MM)
    {
        MM.addAttribute("sellitem");
        return "SellItem";
    }
    
    
    //Mapping URL requests - About Us
    @RequestMapping(value = "/AboutUs", method = RequestMethod.GET)
    public String AboutUs(ModelMap MM)
    {
        MM.addAttribute("aboutus");
        return "AboutUs";
    }
    
    //Mapping URL requests - Log Out
    @RequestMapping(value = "/LoggedOut", method = RequestMethod.GET)
    public String LoggedOut(ModelMap MM)
    {
        MM.addAttribute("loggedout");
        return "Login";
    }
}